<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="desain.css">
</head>
<body>
<header><p>PERPUSTAKAAN</p>
     <ul>
         <a href="form-peminjaman.php">PEMINJAMAN</a>
         <a href="form-buku.php">BUKU</a>
         <a href="logout.php">Logout</a>
     </ul>
    </header>
        <section>
            <article>
        
    <form method="post" action="simpan.php">
      <table class="r">
         <tr>
              <td>Nama pustakawan</td>
          <td>
              <input type="text" name="buku_judul" required>
          </td>
         </tr>
         <tr>
              <td>Jenis pustakawan</td>
          <td>
              <input type="date" name="buku_tgl_stok" required>
          </td>
         </tr>
         <tr>
              <td>Jumlah buku</td>
          <td>
              <input type="number" name="buku_jumlah" required>
          </td>
         </tr>
            <td></td>
            <td><button type="submit">Simpan</button></td>
        </tr>
    </table>
    </form>
    <form class="cr" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
    <input type="text" name="caridata" placeholder="Cari buku.." required>
    <button class="cari" type="submit" name="btncari">Cari</button>
    <table class="tb" border= "1" cellpadding="5">
        <tr>
            <td>NO</td>
            <td>JUDUL BUKU</td>
            <td>TANGGAL STOK BUKU</td>
            <td>JUMLAH BUKU</td>
            <td>TINDAKAN</td>
        </tr>
        <?php
            include "koneksi.php";
            $no=0;
            $panggilsql=mysqli_query($koneksi,"CALL tampil_buku()");
              while($data=mysqli_fetch_array($panggilsql)) {
             $no++;
             echo "<tr class='h'>
                <td>$no</td>
                <td>$data[buku_judul]</td>
                <td>$data[buku_tgl_stok]</td>
                <td>$data[buku_jumlah]</td>
                <td>
                <form method='post' action='edit.php'>
                   <input type='hidden' name='buku_id' value='$data[buku_id]'>
                   <button type='submit'>Edit</button>
                </form>
                <form method='post' action='hapus.php'>
                    <input type='hidden' name='buku_id' value='$data[buku_id]'>
                    <button type='submit'>Hapus</button>
                </form>
                </td>
             </tr>";
            }
        ?>
</body>
</html>