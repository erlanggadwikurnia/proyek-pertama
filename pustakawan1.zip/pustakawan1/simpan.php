<?php
include "koneksi.php";


$bukujudul=$_POST['judul_buku'];
$bukutglstok=$_POST['buku_tgl_stok'];
$bukujumlah=$_POST['buku_jumlah'];

if(mysqli_query($koneksi,"CALL tambah_buku('$bukujudul','$bukutglstok','$bukujumlah')")) {
    echo '<script>
    alert("Data telah tersimpan");
    </script>
     <meta http-equiv="refresh" content="0, form-buku.php">';
} else {
    echo '<script>
    alert("Data gagal disimpan");
    </script>
    <meta http-equiv="refresh" content="0, form-buku.php">';
}