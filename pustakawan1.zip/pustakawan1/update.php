<?php
include "koneksi.php";

$idbuku=$_POST['buku_id'];
$bukujudul=$_POST['judul_buku'];
$bukutglstok=$_POST['buku_tgl_stok'];
$bukujumlah=$_POST['buku_jumlah'];

if(mysqli_query($koneksi,"CALL update_pustakawan('$idbuku','$bukujudul','$bukutglstok','$bukujumlah')")) {
    echo '<script>
    alert("Data berhasil diedit");
    </script>
     <meta http-equiv="refresh" content="0, form-buku.php">';
} else {
    echo '<script>
    alert("Data gagal diedit");
    </script>
    <meta http-equiv="refresh" content="0, form-buku.php">';
}