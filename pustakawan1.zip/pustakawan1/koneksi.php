<?php
$koneksi=mysqli_connect("localhost","root","","perpustakaan1") or die("gagal mengkoneksikan");
mysqli_select_db($koneksi,"perpustakaan1") or die("database tidak ada");