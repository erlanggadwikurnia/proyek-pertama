<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="desain.css">
</head>
<body>
    <?php
        if(empty($_POST['buku_id'])) {
            header('location:form-buku.php');
        } else {
            include "koneksi.php";
            $idbrg=$_POST['buku_id'];
            $sqledit=mysqli_query($koneksi, "SELECT * FROM buku WHERE buku_id='$idbuku'");
            while($data=mysqli_fetch_array($sqledit)) {
                echo ' <form method="post" action="update.php">
                <input type="hidden" name="buku_id" value="' .$data['buku_id']. '">
                <table>
                   <tr>
                        <td>Judul buku</td>
                    <td>
                        <input type="text" name="buku_judul" value="'.$data['buku_judul']. '"required>
                    </td>
                   </tr>
                   <tr>
                        <td>Buku tanggal  stok</td>
                    <td>
                        <input type="number" name="buku_tgl_stok" value="'.$data['buku_tgl_stok']. '"required>
                    </td>
                   </tr>
                   <tr>
                        <td>Jumlah buku</td>
                    <td>
                        <input type="number" name="buku_jumlah" value="'.$data['buku_jumlah']. '"required>
                    </td>
                   </tr>
                   <tr>
                      <td></td>
                      <td><button type="submit">Update</button></td>
                  </tr>
               </table>
              </form>';
            }
        }
    ?>
</body>
</html>